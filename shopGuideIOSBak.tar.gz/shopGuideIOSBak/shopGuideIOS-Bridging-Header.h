//
//  shopGuideIOS-Bridging-Header.h
//  shopGuideIOS
//
//  Created by apple on 2019/11/5.
//  Copyright © 2019 apple. All rights reserved.
//

#ifndef shopGuideIOS_Bridging_Header_h
#define shopGuideIOS_Bridging_Header_h

#import "WXApi.h"
#import "WXApiObject.h"
#import "WechatAuthSDK.h"

#endif /* shopGuideIOS_Bridging_Header_h */
