//
//  NetConnectView.swift
//  shopGuideIOS
//
//  Created by apple on 2020/1/3.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI
import Alamofire

struct NetConnectView: View {
    @EnvironmentObject var systemInfo: SystemInfo
    let netManager = NetworkReachabilityManager(host: "www.apple.com")
    
    var body: some View {
        VStack(alignment: .center) {
            Image("netClose")
                .resizable()
                .frame(width: SCREEN_W * 0.6, height: SCREEN_W * 0.6 * 0.6, alignment: .center)
            
            Text("网络连接丢失")
                .foregroundColor(Color.gray)
                .padding(.bottom, 10)
            
            Text("请允许“买就返利”使用WLAN与蜂窝数据")
                .foregroundColor(Color.gray)
                .padding(.bottom, 10)
            
            Button(action: {
                self.netManager?.startListening( onUpdatePerforming: {
                    status in
                    switch status {
                    case .unknown, .notReachable:
                        print("not reach")
                        
                        if let url = URL(string: UIApplication.openSettingsURLString), UIApplication.shared.canOpenURL(url) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        }
                        break
                    case .reachable:
                        print("reachable")
                        
                        self.systemInfo.netUsable = true
                        self.netManager?.stopListening()
                        
                        // 获取初始配置
                        ApiBase.shared.requestForDict("/app2/buss124/conf", false,
                            bussParam: [:],
                            succFunc: { respDict in
                                self.systemInfo.wait = respDict["wait"] as? Bool ?? true

                                let respClassic = respDict["classic"] as? [String] ?? []
                                self.systemInfo.classic += respClassic

                                self.systemInfo.tips = respDict["tips"] as? String ?? ""

                            },
                            failFunc: { code, msg in
                                print("\(code) @ \(msg)")
                            }
                        )
                        break
                    }
                })
                
            }) {
                Text("重新连接")
                    .frame(width: 200, height: 60)
                    .font(Font.system(size: 20, weight: .heavy, design: .monospaced))
                    .background(Color(red: 108/255, green: 225/255, blue: 218/255))
                    .cornerRadius(10)
                    .foregroundColor(.white)
            } // button
//            .buttonStyle(PlainButtonStyle())

        }// end VStack
    }
}

struct NetConnectView_Previews: PreviewProvider {
    static var tmpSystemInfo = SystemInfo(netUsable: true)
    
    static var previews: some View {
        NetConnectView().environmentObject(self.tmpSystemInfo)
    }
}
