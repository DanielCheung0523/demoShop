//
//  ContentView.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/5.
//  Copyright © 2019 apple. All rights reserved.
//

import SwiftUI


let items: [BottomBarItem] = [
    BottomBarItem(icon: "house.fill", title: "首页", color: .purple),
    BottomBarItem(icon: "heart", title: "收藏", color: .pink),
    BottomBarItem(icon: "magnifyingglass", title: "查找", color: .orange),
    BottomBarItem(icon: "person.fill", title: "我的", color: .blue)
]




struct ContentView: View {
    @State private var selectedIndex = TAB_TAG_HOME
    @EnvironmentObject var systemInfo: SystemInfo
    
    
    var body: some View {
        
        Group {
            if self.systemInfo.netUsable {
                NavigationView {
                    VStack {
                        
                        if self.selectedIndex == TAB_TAG_HOME {
                            
                            Home2View().environmentObject(self.systemInfo)
                            
                            BottomBar(selectedIndex: $selectedIndex, items: items);
                            
                        } else if self.selectedIndex == TAB_TAG_LIKE {
                            
                            Favourite2View().environmentObject(self.systemInfo)
                            
                            BottomBar(selectedIndex: $selectedIndex, items: items);
                            
                        } else if self.selectedIndex == TAB_TAG_SEARCH {
                            
                            Search2View().environmentObject(self.systemInfo)
                            
                            BottomBar(selectedIndex: $selectedIndex, items: items);
                            
                        } else if self.selectedIndex == TAB_TAG_MY {
                            
                            My2View().environmentObject(self.systemInfo)
                            
                            BottomBar(selectedIndex: $selectedIndex, items: items);
                            
                        }

                    } // end VStack
                } // end NavigationView
                
            } else {
                NetConnectView().environmentObject(self.systemInfo)
            }
        } // end group
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    
    static var tmpSystemInfo = SystemInfo(netUsable: true)
    
    static var previews: some View {
        ContentView()
        .environmentObject(tmpSystemInfo)
    }
}
#endif
