//
//  HomeView.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/2.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI


struct TileView: View {
    
    let icon: String
    
    var body: some View {
        VStack {
            ZStack {
                Rectangle()
                    .fill(Color.gray)
                    .cornerRadius(20.0)
                Image(systemName: icon)
                    .imageScale(.large)
                    .font(.largeTitle)
            }
        }
    }
}



struct Home2View: View {
    @EnvironmentObject var systemInfo: SystemInfo
    
    @State var curActTabIdx = 0                     // 当前激活的tab
    @State var curTabGoodIdx:[Int: Int] = [:]       // 当前各tab下被展示的商品
    
    @State var tabGoodList: [Int : [StructTaobao]] = [:]   // 各tab下加载的商品列表
    
    
    var body: some View {
        NavigationView {
            
            ZStack {
                
                VStack(alignment: .leading) {
                    // 分类标题栏
                    ClassicView(selectedIdx: $curActTabIdx, classic: self.systemInfo.classic)
                    
                    // 滚动通知信息
                    if self.systemInfo.tips.count > 0 {
                        Text(self.systemInfo.tips)
                    }
                    
                }// end VStack
                .frame(width: SCREEN_W * 0.95)
                .zIndex(200)
                .position(y: 0)
                

                // 分类视图
                GeometryReader { geometry in
                    PagingScrollView(
                        activePageIndex: self.$curActTabIdx,
                        itemCount: self.systemInfo.classic.count,
                        pageWidth: geometry.size.width,
                        tileWidth: SCREEN_W * 0.98,
                        tilePadding: 2) {
                            
                        ForEach(0 ..< self.systemInfo.classic.count) { index in
                            GeometryReader { geometry2 in
                                TileView(icon: "\(index + 1).circle")
                                    .onTapGesture {
                                        print ("tap on index: \(index)")
                                }
                                .onAppear {
                                    print("\(index) on appear")
                                    if self.curActTabIdx == index { // 请求当前激活的页面数据
                                        self.requestClassicList(tabAt: index)
                                    }
                                }
                            } // end GeometryReader
                        } // end ForEach
                    } // end PagingScrollView
                    .zIndex(100)
                } // end GeometryReader
                
                
                // 右侧按钮区
                VStack {
                    Text(".")
                } // end VStack
                .zIndex(200)
                
                // 左下角信息区
                VStack {
                    Text("..")
                } // end VStack
                .zIndex(200)
                
            } // end ZStack
            .edgesIgnoringSafeArea([.top])

        } // end NavigationView
//        .navigationBarItems(
//            leading:
//            SwiftyUIScrollView(
//                axis: .horizontal,
//                numberOfPages: self.systemInfo.classic.count,
//                pagingEnabled: true,
//                pageControlEnabled: true,
//                hideScrollIndicators: false
//            ){
//                HStack(spacing: 5) {
//                    ForEach(0 ..< self.systemInfo.classic.count) { idx in
//                        Text(self.systemInfo.classic[idx])
//                    }
//                }
//                .frame(width: SCREEN_W * 0.9, height: SCREEN_H * 0.2)
//                .padding(.top, 30)
//            }
//            ,trailing :
//            NavigationLink(destination: Search2View()) {
//                Image("V2_search")
//                .resizable()
//                .aspectRatio(contentMode: .fill)
//                .frame(width: 30.0, height: 30.0)
//            }
//        ) // end navigationBarItems

    } // end body
    
    
    /// 请求分类列表数据
    func requestClassicList(tabAt: Int) {
        
        let loadFirst = (self.tabGoodList[tabAt] ?? []).count > 0 ? false : true    // 是否首次加载
        if !loadFirst {
            let lessNum = (self.tabGoodList[tabAt]?.count ?? 0) - ((self.curTabGoodIdx[tabAt] ?? -1) + 1)
            if lessNum > 3 { // 上滑动到剩余3个时,加载下一页
                return
            }
        }
        
        ApiBase.shared.requestForArray("/app2/buss124/list", false,
            bussParam: ["classic" : self.systemInfo.classic[tabAt]],
            succFunc: { respArray in
                
                if loadFirst {
                    self.tabGoodList[tabAt]?.removeAll()
                }
                
                // append data
                for tmpGood in respArray {
                    
                    var newGood = StructTaobao()
                    newGood.itemId = tmpGood["item_id"] as? String ?? ""
                    newGood.itemUrl = tmpGood["item_url"] as? String ?? ""
                    newGood.title = tmpGood["title"] as? String ?? ""
                    newGood.finalPrice = tmpGood["zk_final_price"] as? Double ?? 0.00
                    newGood.couponPrice = tmpGood["coupon_price"] as? Double ?? 0.00
                    newGood.commissionPrice = tmpGood["commission_price"] as? Double ?? 0.00
                    newGood.volumn = tmpGood["volumn"] as? Int ?? 0
                    newGood.mainPic = tmpGood["main_pic"] as? String ?? ""
                    newGood.smallPics = tmpGood["small_pics"] as? [String] ?? []
                    newGood.nick = tmpGood["nick"] as? String ?? ""
                    newGood.isFavourite = tmpGood["favourite"] as? Bool ?? false
                    
                    self.tabGoodList[tabAt]?.append(newGood)
                }
                
            },
            failFunc: { code, msg in
                print("\(code) @ \(msg)")
            }
        )
        
        
    }
}

struct Home2View_Previews: PreviewProvider {
    static var tmpSystemInfo = SystemInfo(netUsable: true)
    
    static var previews: some View {
        Home2View()
        .environmentObject(tmpSystemInfo)
    }
}
