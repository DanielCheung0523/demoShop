//
//  Favourite2View.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/2.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI

struct Favourite2View: View {
    @EnvironmentObject var systemInfo: SystemInfo
    
    var body: some View {
        NavigationView {
            Text("Favourite")
        }
        .onAppear {
            print("favourite appear")
        }
    }
}

struct Favourite2View_Previews: PreviewProvider {
    static var previews: some View {
        Favourite2View()
    }
}
