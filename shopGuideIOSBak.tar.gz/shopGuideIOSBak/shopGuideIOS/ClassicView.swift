//
//  ClassicView.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/8.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI

struct ClassicView: View {
    @Binding public var selectedIdx: Int
    public let classic: [String]
    
    public init(selectedIdx: Binding<Int>, classic: [String]) {
        self._selectedIdx = selectedIdx
        self.classic = classic
    }
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .top, spacing: 10) {
                ForEach(0 ..< self.classic.count) { idx in
                    Button(action: {
                        self.selectedIdx = idx
                    }) {
                        VStack(alignment: .center, spacing: 5) {
                            
                            Text(self.classic[idx])
                                .font(Font.system(size: 18, weight: .medium, design: .rounded))
                                .foregroundColor( self.selectedIdx == idx ? Color.purple : Color.white)
                            
                            if self.selectedIdx == idx { // 底部下滑线
                                Rectangle()
                                    .frame(height: 5)
                                    .foregroundColor(Color.purple)
                                    .cornerRadius(5)
                            }
                        }
                    }
                }
            }
        }
    }
}

struct ClassicView_Previews: PreviewProvider {
    static var previews: some View {
        ClassicView(selectedIdx: .constant(0), classic: ["推荐", "男装", "女装"])
    }
}
