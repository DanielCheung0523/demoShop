//
//  Date+Extension.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2019/11/11.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

extension Date {
    
    /// 当前时间秒
    var curSecondStampInt: Int {
        let timeInterval: TimeInterval = self.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        return timeStamp
    }


    /// 当前时间秒
    var curSecondStampIntStr: String {
        let timeInterval: TimeInterval = self.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        return "\(timeStamp)"
    }


    /// 当前时间毫秒
    var curMilliStampStr: String {
        let timeInterval: TimeInterval = self.timeIntervalSince1970
        let millisecond = CLongLong(round(timeInterval*1000))
        return "\(millisecond)"
    }
    
    /// 当前日期
    func curDateTime(format: String) -> String {
        let now = Date()
        let dformatter = DateFormatter()
        dformatter.dateFormat = format
        return dformatter.string(from: now)
    }
    
    /// 时间戳转时间格式
    func formatSecondsStamp(time:Int, format:String) -> String {
        let timeInterval = TimeInterval(time)
        let date = Date.init(timeIntervalSince1970: timeInterval)
        let dateFormatte = DateFormatter()
        dateFormatte.dateFormat = format
        return dateFormatte.string(from: date)
    }
    
    /// 时间格式转秒
    func stringFormat2Seconds(timeString:String, format:String) -> Int {
        let dateFormatte = DateFormatter()
        dateFormatte.dateFormat = format
        
        let tmpDate = dateFormatte.date(from: timeString)
        return Int(tmpDate?.timeIntervalSince1970 ?? 0)
    }
}


