//
//  WebView.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/6.
//  Copyright © 2019 apple. All rights reserved.
//
//
import SwiftUI
import WebKit
import Combine

class WebViewModel: ObservableObject {
    @Published var link: String
    @Published var didFinishLoading: Bool = false

    init (link: String) {
        self.link = link
    }
}

struct SwiftUIWebView: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    @State var forbiddenClick = false
    @State var injectJS = true

    let webView = WKWebView()
    

    func makeUIView(context: UIViewRepresentableContext<SwiftUIWebView>) -> WKWebView {
        self.webView.navigationDelegate = context.coordinator
        
        if let url = URL(string: viewModel.link) {
            self.webView.load(URLRequest(url: url))
        }
        
        return self.webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<SwiftUIWebView>) {
        return
    }
    
    
    class Coordinator: NSObject, WKNavigationDelegate {
        private var viewModel: WebViewModel
        private var forbiddenClick: Bool
        private var injectJS: Bool

        init(_ viewModel: WebViewModel, _ forbiddenClick: Bool, _ injectJS: Bool) {
            self.viewModel = viewModel
            self.forbiddenClick = forbiddenClick
            self.injectJS = injectJS
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            self.viewModel.didFinishLoading = true
            
            if self.forbiddenClick {
                let forbiddenClick = "function handler(e) { e.stopPropagation(); e.preventDefault(); } ; document.addEventListener(\"click\", handler, true);"
                webView.evaluateJavaScript(forbiddenClick, completionHandler: nil)
            }
            
            if self.injectJS {
                // 删除尾部购买bar
                let js = "document.getElementById(\"s-actionBar-container\").remove()"
                webView.evaluateJavaScript(js, completionHandler: nil)
                
                // 删除内容容器
                let containerJs = "document.getElementById(\"detailInfoContainer\").remove()"
                webView.evaluateJavaScript(containerJs, completionHandler: nil)
                
                // 删除推荐
                let recommendJs = "document.getElementById(\"detail-recommend\").remove()"
                webView.evaluateJavaScript(recommendJs, completionHandler: nil)
                
                // 删除顶部app下载bar
                let appDownLoadJs = "document.getElementById(\"head\").remove()"
                webView.evaluateJavaScript(appDownLoadJs, completionHandler: nil)
            }
        }
    }
    
    func makeCoordinator() -> SwiftUIWebView.Coordinator {
        Coordinator(viewModel, self.forbiddenClick, self.injectJS)
    }
    
    func back() {
        self.webView.goBack()
    }

    func forward(){
        self.webView.goForward()
    }
}

struct SwiftUIWebView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIWebView(viewModel: WebViewModel(link: "https://s.click.taobao.com/t?e=m%3D2%26s%3D5j7NaGn1nUpw4vFB6t2Z2ueEDrYVVa64Dne87AjQPk9yINtkUhsv0BQl%2BZC60D%2FHW%2BZ04xg4DdCNdxuecdX6fPuRN4OdNbFEgSJQkkwkeJrvs%2FY364%2B%2Bn01ZQKE367JRgvUNyyJS1KL3%2BWMkG3VUs0%2Bwmr8UGGDDFGoZ11nyTy%2BMHuv7RoNv0cDr3R%2F7QRWeXypWabiJa9WbroCw79YKp1K5ivcm4hVEWjd1Jmo1CfrGJe8N%2FwNpGw%3D%3D&scm=1007.19011.125585.0_13366&pvid=6dec5427-1f11-401e-9a4e-99ac7fa6f999&app_pvid=59590_11.132.118.135_476_1573969742874&ptl=floorId:13366;originalFloorId:13366;pvid:6dec5427-1f11-401e-9a4e-99ac7fa6f999;app_pvid:59590_11.132.118.135_476_1573969742874&union_lens=lensId%3AOPT%401573969743%400b847687_419d_16e77e84cf2_541f%4001"), forbiddenClick: true, injectJS: true)
    }
}

