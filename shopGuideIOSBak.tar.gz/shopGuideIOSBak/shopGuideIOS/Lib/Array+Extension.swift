//
//  Array+Extension.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/1/11.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation

extension Array where Element:Hashable {
    mutating func removeDuplicates() {
        var result = [Element]()
        for value in self {
            if !result.contains(value) {
                result.append(value)
            }
        }
        self = result
    }
}
