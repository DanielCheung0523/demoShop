//
//  ActivityIndicator.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2019/12/14.
//  Copyright © 2019 apple. All rights reserved.
//

///
/// VERSION 1:
///
//import SwiftUI
//
//struct ActivityIndicator: UIViewRepresentable {
//
//    @Binding var isAnimating: Bool
//    let style: UIActivityIndicatorView.Style
//
//    func makeUIView(context: UIViewRepresentableContext<ActivityIndicator>) -> UIActivityIndicatorView {
//        return UIActivityIndicatorView(style: style)
//    }
//
//    func updateUIView(_ uiView: UIActivityIndicatorView, context: UIViewRepresentableContext<ActivityIndicator>) {
//        isAnimating ? uiView.startAnimating() : uiView.stopAnimating()
//    }
//}


///
/// VERSION 2: https://github.com/ericlewis/ActivityIndicatorView
///
import SwiftUI

public struct ActivityIndicatorView: UIViewRepresentable {
    @Binding var isAnimating: Bool
    var color: UIColor

    private var style: UIActivityIndicatorView.Style?

    public init(isAnimating: Binding<Bool>, style: UIActivityIndicatorView.Style? = nil, color: UIColor = .systemGray) {
        _isAnimating = isAnimating
        self.style = style
        self.color = color
    }

    public func makeUIView(context: Context) -> UIActivityIndicatorView {
        guard let style = self.style else {
            return UIActivityIndicatorView()
        }

        return UIActivityIndicatorView(style: style)
    }

    public func updateUIView(_ uiView: UIActivityIndicatorView, context: Context) {
        uiView.color = color
        isAnimating ? uiView.startAnimating() : uiView.stopAnimating()
    }
}

public extension ActivityIndicatorView {
    init(style: UIActivityIndicatorView.Style? = nil, color: UIColor = .systemGray) {
        self.init(isAnimating: .constant(true), style: style, color: color)
    }
}



///
/// VERSION 3 : https://github.com/emartife/ActivityIndicatorView
///
//import SwiftUI
//import UIKit
//
//public struct ActivityIndicator: UIViewRepresentable {
//
//    public typealias UIViewType = UIActivityIndicatorView
//
//    let style: UIActivityIndicatorView.Style
//
//    public func makeUIView(context: UIViewRepresentableContext<ActivityIndicator>) -> ActivityIndicator.UIViewType {
//        return UIActivityIndicatorView(style: style)
//    }
//
//    public func updateUIView(_ uiView: ActivityIndicator.UIViewType, context: UIViewRepresentableContext<ActivityIndicator>) {
//        uiView.startAnimating()
//    }
//}
//
//@available(iOS 13.0, *)
//public struct ActivityIndicatorView<Content>: View where Content: View {
//    private var isShowing: Binding<Bool>
//    private var content: () -> Content
//
//    public init(isShowing: Binding<Bool>, content: @escaping () -> Content) {
//        self.isShowing = isShowing
//        self.content = content
//    }
//
//    public var body: some View {
//        ZStack(alignment: .center) {
//            if (!self.isShowing.wrappedValue) {
//                self.content()
//            } else {
//                self.content()
//                    .disabled(true)
//                    .blur(radius: 3)
//
//                VStack {
//                    ActivityIndicator(style: .large)
//                }
//                .frame(width: 100.0, height: 100.0)
//                .background(Color.secondary.colorInvert())
//                .foregroundColor(Color.primary)
//                .cornerRadius(20)
//            }
//        }
//    }
//}
