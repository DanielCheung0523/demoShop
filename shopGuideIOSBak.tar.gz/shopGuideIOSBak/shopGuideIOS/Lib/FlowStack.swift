//
//  FlowStack.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/26.
//  Copyright © 2019 apple. All rights reserved.
//

import SwiftUI


@available(iOS 13.0, OSX 10.15, tvOS 13.0, watchOS 6.0, *)
public struct FlowStack<Content>: View where Content: View {
    // Scrollable
    var scroll: Bool
    // The number of columns we want to display
    var columns: Int
    // The total number of items in the stack
    var numItems: Int
    // Horizontal Space
    var horSpace: CGFloat
    // Vertical Space
    var verSpace: CGFloat
    // The alignment of our columns in the last row
    // when they don't fill all the column slots
    var alignment: HorizontalAlignment

    public let content: (Int, CGFloat) -> Content

    public init(
        scroll: Bool,
        columns: Int,
        numItems: Int,
        horSpace: CGFloat,
        verSpace: CGFloat,
        alignment: HorizontalAlignment?,
        @ViewBuilder content: @escaping (Int, CGFloat) -> Content
    ){
        self.scroll = scroll
        self.content = content
        self.columns = columns
        self.numItems = numItems
        self.horSpace = horSpace
        self.verSpace = verSpace
        self.alignment = alignment ?? HorizontalAlignment.leading
    }

    public var body : some View {
        // A GeometryReader is required to size items in the scroll view
        GeometryReader { geometry in
            // Assume a vertical scrolling orientation for the grid
            if self.scroll {
                ScrollView(Axis.Set.vertical) {

                    // VStacks are our rows
                    VStack(alignment: self.alignment, spacing: self.verSpace) {
                        ForEach(0 ..< (self.numItems / self.columns), id: \.self) { row in

                            // HStacks are our columns
                            HStack(spacing: self.horSpace) {
                                ForEach(0 ... (self.columns - 1), id: \.self) { column in
                                    self.content(
                                        // Pass the index to the content
                                        (row * self.columns) + column,
                                        // Pass the column width to the content
                                        (geometry.size.width/CGFloat(self.columns))
                                    )
                                        // Size the content to frame to fill the column
                                        .frame(width: geometry.size.width/CGFloat(self.columns))
                                }// end foreach
                            }// end hstack
                        }// end foreach

                        // Last row
                        // HStacks are our columns
                        HStack(spacing: self.horSpace) {
                            ForEach(0 ..< (self.numItems % self.columns)) { column in
                                self.content(
                                    // Pass the index to the content
                                    ((self.numItems / self.columns) * self.columns) + column,
                                    // Pass the column width to the content
                                    (geometry.size.width/CGFloat(self.columns))
                                )
                                // Size the content to frame to fill the column
                                .frame(width: geometry.size.width/CGFloat(self.columns))
                            }// end foreach
                        } // end HStack
                    } // end vstack
                } // end ScrollView
            } else {
                // VStacks are our rows
                VStack(alignment: self.alignment, spacing: self.verSpace) {
                    ForEach(0 ..< (self.numItems / self.columns), id: \.self) { row in

                        // HStacks are our columns
                        HStack(spacing: self.horSpace) {
                            ForEach(0 ... (self.columns - 1), id: \.self) { column in
                                self.content(
                                    // Pass the index to the content
                                    (row * self.columns) + column,
                                    // Pass the column width to the content
                                    (geometry.size.width/CGFloat(self.columns))
                                )
                                    // Size the content to frame to fill the column
                                    .frame(width: geometry.size.width/CGFloat(self.columns))
                            }// end foreach
                        }// end hstack
                    }// end foreach

                    // Last row
                    // HStacks are our columns
                    HStack(spacing: self.horSpace) {
                        ForEach(0 ..< (self.numItems % self.columns)) { column in
                            self.content(
                                // Pass the index to the content
                                ((self.numItems / self.columns) * self.columns) + column,
                                // Pass the column width to the content
                                (geometry.size.width/CGFloat(self.columns))
                            )
                            // Size the content to frame to fill the column
                            .frame(width: geometry.size.width/CGFloat(self.columns))
                        }// end foreach
                    } // end HStack
                } // end vstack
            }// end if
        } // end GeometryReader
    }// end body
}

