//
//  URL+Extension.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/13.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

extension URL{
    
    static func initPercent(string: String) -> URL
    {
        let urlwithPercentEscapes = string.addingPercentEncoding( withAllowedCharacters: .urlQueryAllowed)
        let url = URL.init(string: urlwithPercentEscapes!)
        return url!
    }
}
