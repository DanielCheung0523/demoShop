//
//  Double+Extension.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/27.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

extension Double {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
}
