//
//  AppDelegate.swift
//  shopGuideIOS
//
//  Created by apple on 2019/11/5.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import SwiftUI
import CoreData
import Alamofire

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, WXApiDelegate {

    var window: UIWindow?
    var systemInfo = SystemInfo()
    let netManager = NetworkReachabilityManager(host: "www.apple.com")
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        WXApi.registerApp(APPID_WXOPEN, universalLink: UNIVERSAL_LINK_WXOPEN)
        
        // 网络可访问状态
        if self.netManager?.isReachable ?? false {
            
            self.systemInfo.netUsable = true
            
            // 获取初始配置
            ApiBase.shared.requestForDict(
                "/app2/buss124/conf",
                false,
                bussParam: [:],
                succFunc: { respDict in
                    self.systemInfo.wait = respDict["wait"] as? Bool ?? true
                    
                    let respClassic = respDict["classic"] as? [String] ?? []
                    self.systemInfo.classic += respClassic
                    self.systemInfo.tips = respDict["tips"] as? String ?? ""
            },
                failFunc: { code, msg in
                    print("\(code) @ \(msg)")
            }
            )
            
        } else {

            self.netManager?.startListening( onUpdatePerforming: { netStatus in
                switch netStatus {
                case .reachable:

                    self.systemInfo.netUsable = true
                    self.netManager?.stopListening()

                    // 获取初始配置
                    ApiBase.shared.requestForDict(
                        "/app2/buss124/conf",
                        false,
                        bussParam: [:],
                        succFunc: { respDict in
                            self.systemInfo.wait = respDict["wait"] as? Bool ?? true

                            let respClassic = respDict["classic"] as? [String] ?? []
                            self.systemInfo.classic += respClassic

                            self.systemInfo.tips = respDict["tips"] as? String ?? ""

                        },
                        failFunc: { code, msg in
                            print("\(code) @ \(msg)")
                        }
                    )

                    break
                default:
                    break
                }
                
            })
            
        }
        

        // 加载根页面
        let contentView = ContentView()
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = UIHostingController(rootView: contentView.environmentObject(self.systemInfo))
        window.makeKeyAndVisible()
        self.window = window

        return true
    }
    
    /// @Link https://www.jianshu.com/p/8659851b5e94
    func application(_ application: UIApplication, handleOpen url: URL) -> Bool {
        if url.scheme == APPID_WXOPEN {
            return WXApi.handleOpen(url, delegate: self)
        }

        return true
    }
    
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        if url.scheme == APPID_WXOPEN {
            return WXApi.handleOpen(url, delegate: self)
        }

        return true
    }
    
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        if url.scheme == APPID_WXOPEN {
            return WXApi.handleOpen(url, delegate: self)
        }

        return true
    }
    
    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        return WXApi.handleOpenUniversalLink(userActivity, delegate: self)
    }
    

    func onReq(_ req: BaseReq) {
        
    }
    
    func onResp(_ resp: BaseResp) {
        if resp.errCode == 0 {
            if resp.type == 0 { // 授权登录
                guard let authResp = resp as? SendAuthResp else {
                    return
                }
                
                //let queue = DispatchQueue(label: "wxLoginQueue")
                let state = authResp.state ?? ""    // login - 登录、bind_### - 绑定微信
                
                if state.count < 1 {
                    return
                }
                
                guard let respCode = authResp.code else {
                    return
                }
                
                var type = ""
                var param = ""
                
                if let dotIdx = state.firstIndex(of: "_") {
                    type = String(state.prefix(upTo: dotIdx))
                    param = String(state.suffix(from: state.index(dotIdx, offsetBy: 1)))
                } else {
                    type = state
                }
                
                //DispatchQueue.main.async {
                    var urlStr = ""
                    switch type {
                    case "login":
                        urlStr = "\(DOMAIN)/app/wechat/login/?v=\(VERSION)&code=\(respCode)"
//                    case "bind":
//                        urlStr = "\(DOMAIN)/app/buss111/bindwx/?v=\(VERSION)&token=\(UserData.shared.token)&code=\(respCode)&uid=\(param)"
                    default:
                        return
                    }
                    
                    let reqURL = URL(string: urlStr)
                    do {
                        let respLogin = try Data.init(contentsOf: reqURL!, options: Data.ReadingOptions.alwaysMapped)
                        let respDict = try JSONSerialization.jsonObject(with: respLogin, options: JSONSerialization.ReadingOptions.allowFragments) as? Dictionary<String, AnyObject>

                        guard respDict != nil else {
                            return
                        }
                        
                        guard let code: Int = respDict!["code"] as? Int else {
                            return
                        }
                        
                        if code > 0 {
                            return
                        }

                        if let respData = respDict!["data"] {
                            let token: String = respData["token"] as? String ?? ""

                            if !token.isEmpty {// 登录成功
//                                UserData.shared.updUserInfo(userInfo: respData as! [String : Any])
                                
//                                self.logStatus.isLog = true // @todo 未被执行
                            }
                        } else {
                        }
                    } catch {
                    } // end do
                //}// end async
            }
        }
    }

}
