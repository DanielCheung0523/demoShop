//
//  TaobaoStruct.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/3/30.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation

struct StructTaobao : Hashable {
    
    static func == (lhs: StructTaobao, rhs: StructTaobao) -> Bool {
        return lhs.itemId == rhs.itemId
    }
    
    var hashId: UUID = UUID()
    var itemId = ""             // 商品ID
    var itemUrl = ""            // 商品详情页
    var title = ""              // 商品标题
    var finalPrice = 0.00       // 商品折扣价(0.00元)
    var couponPrice = 0.00      // 优惠券金额(0.00元)
    var commissionPrice = 0.00  // 返佣金额(0.00元)
    var volumn = 0              // 售量
    var mainPic = ""            // 商品主图
    var smallPics = [String]()  // 商品小图
    var nick = ""               // 店铺名
    var isFavourite = false     // 是否已收藏
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(hashId)
    }
}
