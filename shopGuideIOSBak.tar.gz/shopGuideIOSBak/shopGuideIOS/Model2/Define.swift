//
//  Define.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/3/30.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation
import AdSupport

// 设备相关定义
let SCREEN_W = UIScreen.main.bounds.width       // 屏幕宽度
let SCREEN_H = UIScreen.main.bounds.height      // 屏幕高度

let MAJOR_V = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""        // 主版本号：1.2
let MINOR_V = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? ""                   // 小版本号：4
let VERSION = "\(MAJOR_V).\(MINOR_V)"           // 版本号: 1.2.4

let OS_VERSION = UIDevice.current.systemVersion // iOS版本号：13.3.1
let DEV_MODEL = UIDevice.modelName()            // 设备型号：  iPhoneXR / iPhoneXS / iPad11,3 等
let IDFA = ASIdentifierManager.shared().advertisingIdentifier.uuidString



// 苹果登录
let KEY_CHAIN_SVR = "cn.charp.zgl.shopGuideIOS.appleid"
let KEY_CHAIN_EMAIL_KEY = "appleID_email"
let KEY_CHAIN_NAME_KEY = "appleID_name"
let KEY_CHAIN_IDENTIFIER_KEY = "appleID_identifier"




// 业务相关
#if DEBUG
let DOMAIN = "https://testsg.charp.cn"       // 开发环境
#else
let DOMAIN = "https://sg.charp.cn"           // 生产环境
#endif


// 微信分享
let APPID_WXOPEN = "wxd4e09481be9d4e31"                     // app在微信开放平台注册appid
let UNIVERSAL_LINK_WXOPEN = "\(DOMAIN)/coper/wechat/ul/"    // app在微信开放平台配置的Universal Links


let PWD_ENC_KEY = "5ae1b8a17bad4daf"
let PWD_ENC_IV = "34857d973953e44a"


let TAB_TAG_HOME = 0
let TAB_TAG_LIKE = 1
let TAB_TAG_SEARCH = 2
let TAB_TAG_MY = 3

