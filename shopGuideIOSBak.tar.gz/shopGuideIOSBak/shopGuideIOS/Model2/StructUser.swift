//
//  StructUser.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/3/31.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation

struct StructUser: Hashable {
//    static var shared = StructUser()
    
    static func == (lhs: StructUser, rhs: StructUser) -> Bool {
        return lhs.uid == rhs.uid
    }
    
    var hashId: UUID = UUID()
    var uid: String = ""
    var nick: String = ""
    var avatar: String = ""
    var mobile: String = ""
    var freezeBal: Float = 0.00
    var drawBal: Float = 0.00
    
    
    var token: String = ""
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(hashId)
    }
    

}
