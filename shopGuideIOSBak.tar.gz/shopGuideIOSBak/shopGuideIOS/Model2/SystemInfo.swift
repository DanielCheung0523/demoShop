//
//  SystemInfo.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/2.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation

final class SystemInfo: ObservableObject {
    /// 网络状态
    @Published var netUsable : Bool = false
    
    /// 是否审核中
    @Published var wait: Bool = true
    
    /// 分类
    @Published var classic: [String] = []
    
    /// 通知
    @Published var tips: String = ""
    
    /// 用户信息
//    @Published var userInfo : StructUser = StructUser.shared
    
    init() {
        
    }
    
    init(netUsable: Bool) {
        self.netUsable = netUsable
    }
}
