//
//  ApiBase.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/3/31.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation
import Alamofire
import CryptoSwift


final class ApiBase {
    
    static let shared = ApiBase()
    
    private var sessConf = URLSessionConfiguration.af.default
    private var session:Session
    
    private init() {
        self.sessConf.timeoutIntervalForRequest = TimeInterval(5)      // 请求连接超时时间
        self.sessConf.timeoutIntervalForResource = TimeInterval(10)     // 等待响应超时时间
        self.session = Session(configuration: self.sessConf)
    }
    
    /// get request base params
    func baseParams(needCHK: Bool) -> [String: String]{
        
        let curTimeSec = Date().curSecondStampIntStr
        var params = [
            "bVer": VERSION,
            "bDev": IDFA,
            "bType": "ios",
            "bTime": curTimeSec
        ]
        
        if needCHK {
            params["bValid"] = "0"
        } else {
            params["bValid"] = "1"
        }
        
//        params["bToken"] = StructUser.shared.token
        params["bToken"] = ""
        
        let signStr = "type!ios)valid=\(params["bValid"] ?? "0")@token=\(params["bToken"] ?? "")&timeIs\(params["bTime"] ?? "")=dev*\(params["bDev"] ?? "ios")Butv~\(params["bVer"] ?? "")"
        params["bSign"] = signStr.md5()
        
        return params
    }
    
    
    /// request for resp dict
    func requestForDict(
        _ apiUrl: String,
        _ needCHK: Bool,
        bussParam: [String: String],
        succFunc: @escaping ([String: AnyObject]) -> Void,
        failFunc: @escaping (Int, String) -> Void
    ) {
        var url = "\(DOMAIN)\(apiUrl)?"
        let params = self.baseParams(needCHK: needCHK)
        
        for (name, value) in params {
            url += "\(name)=\(value)&"
        }
        
        for (name, value) in bussParam {
            url += "\(name)=\(value)&"
        }
        
        let reqURL = URL.initPercent(string: url)
        self.session.request(reqURL)
            .responseJSON { (response) in

                print("responseJSON")

                switch response.result {
                case .success:
                    if let json = try? JSONSerialization.jsonObject(with: response.data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: AnyObject] {

                        guard let code = json["code"] as? Int else {
                            failFunc(-1, "未返回错误码")
                            return
                        }

                        if code > 0 {
                            guard let msg = json["msg"] as? String else {
                                failFunc(code, "未返回错误信息:\(code)")
                                return
                            }

                            failFunc(code, "\(code):\(msg)")
                        } else {
                            guard let respData = json["data"] as? [String: AnyObject] else {
                                succFunc([:])
                                return
                            }

                            succFunc(respData)
                        }
                    } else {
                        failFunc(-1, "响应格式错误")
                    }
                case .failure(let err):
                    failFunc(-1, "响应异常:\(String(describing: err.localizedDescription))")
                }
        }// end responseJSON
    }
    
    /// request for resp array
    func requestForArray(
        _ apiUrl: String,
        _ needCHK: Bool,
        bussParam: [String: String],
        succFunc: @escaping ([AnyObject]) -> Void,
        failFunc: @escaping (Int, String) -> Void
    ) {
        var url = "\(DOMAIN)\(apiUrl)?"
        let params = self.baseParams(needCHK: needCHK)
        
        for (name, value) in params {
            url += "\(name)=\(value)&"
        }
        
        for (name, value) in bussParam {
            url += "\(name)=\(value)&"
        }
        
        let reqURL = URL.initPercent(string: url)
        self.session.request(reqURL)
            .responseJSON { (response) in
                switch response.result {
                case .success:
                    if let json = try? JSONSerialization.jsonObject(with: response.data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: AnyObject] {
                        
                        guard let code = json["code"] as? Int else {
                            failFunc(-1, "未返回错误码")
                            return
                        }
                        
                        if code > 0 {
                            guard let msg = json["msg"] as? String else {
                                failFunc(code, "未返回错误信息:\(code)")
                                return
                            }
                            
                            failFunc(code, "\(code):\(msg)")
                        } else {
                            guard let respData = json["data"] as? [AnyObject] else {
                                succFunc([])
                                return
                            }
                            
                            succFunc(respData)
                        }
                    } else {
                        failFunc(-1, "响应格式错误")
                    }
                case .failure(let err):
                    failFunc(-1, "响应异常:\(String(describing: err.localizedDescription))")
                }
        }
    }
}

