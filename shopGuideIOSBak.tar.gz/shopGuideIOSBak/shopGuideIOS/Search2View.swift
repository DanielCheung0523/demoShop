//
//  Search2View.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/3.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI

struct Search2View: View {
    @EnvironmentObject var systemInfo: SystemInfo
    
    var body: some View {
        NavigationView {
            Text("search")
        }
    }
}

struct Search2View_Previews: PreviewProvider {
    static var previews: some View {
        Search2View()
    }
}
