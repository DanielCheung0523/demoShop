//
//  My2View.swift
//  shopGuideIOS
//
//  Created by DanielCheung on 2020/4/2.
//  Copyright © 2020 apple. All rights reserved.
//

import SwiftUI

struct My2View: View {
    @EnvironmentObject var systemInfo: SystemInfo
    
    var body: some View {
        NavigationView {
            Text("My")
        }
    }
}

struct My2View_Previews: PreviewProvider {
    static var previews: some View {
        My2View()
    }
}
